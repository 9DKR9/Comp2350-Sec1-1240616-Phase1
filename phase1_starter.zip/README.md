# Automatic and Manual Cars: An Exploratory Study

## Project Description
This project explores how the proportion of automatic and manual cars varies across manufacturing years and car brands. It uses the cars.csv dataset to compare transmission types and describe patterns in the available records.

## Research Question
How does the proportion of automatic cars vary across manufacturing years and car brands?

## Initial Objective
Calculate and compare the percentage of automatic and manual cars by manufacturing year and brand. The project will use tables and charts to identify patterns in this dataset.

## Dataset
- File: `data/cars.csv`
- Number of records: 56,244
- Number of columns: 12
- Transmission values: `auto` and `mechanics` (manual)
- Main variables: `make`, `year`, and `transmission`
- Other columns: `model`, `priceUSD`, `condition`, `mileage(kilometers)`, `fuel_type`, `volume(cm3)`, `color`, `drive_unit`, and `segment`
- Original dataset source: **[Add the original dataset URL and provider before submission.]**
- Topic and dataset approval: **[Confirm approval according to the course requirements.]**

The analysis describes the cars in this dataset. It does not measure sales, market demand, or changes in the entire car market. Manufacturing year is not the year a car was listed or sold.

## Repository Structure
- `README.md`: Project description, question, dataset documentation, and setup instructions.
- `requirements.txt`: Required Python packages.
- `data/cars.csv`: Dataset used in the project.
- `notebooks/phase1.ipynb`: Initial project notebook and dataset preview.

## How to Run the Notebook
1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Create and activate a virtual environment on Linux:

   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

4. Install the required packages:

   ```bash
   python -m pip install -r requirements.txt
   ```

5. Start Jupyter Notebook:

   ```bash
   jupyter notebook
   ```

6. Open `notebooks/phase1.ipynb`, select the environment's Python kernel, and run the cells from top to bottom.

## Initial Analysis Plan
1. Check missing values, duplicates, and data types.
2. Review unusual manufacturing years before analysis.
3. Count automatic and manual cars by manufacturing year and brand.
4. Calculate percentages within each year and brand.
5. Create comparison charts and report group sizes when interpreting percentages.

## Phase 1 Scope
This phase defines the topic, research question, dataset, and repository structure. Detailed cleaning, analysis, and conclusions will be completed in later phases.
